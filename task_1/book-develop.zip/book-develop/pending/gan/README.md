TODO: Write about https://github.com/PaddlePaddle/Paddle/tree/develop/demo/gan
